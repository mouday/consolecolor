# consolecolor
设置pycharm控制台字体颜色
